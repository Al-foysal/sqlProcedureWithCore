﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CoreDbSpCall.Models.DB
{
    public partial class db_core_sp_callContext : DbContext
    {
        public db_core_sp_callContext()
        {
        }

        public db_core_sp_callContext(DbContextOptions<db_core_sp_callContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblDepartment> TblDepartment { get; set; }
        public virtual DbSet<TblProduct> TblProduct { get; set; }
        public virtual DbSet<TblVendor> TblVendor { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("Data Source=DESKTOP-5QQ2JO6;Initial Catalog=db_core_sp_call;Trusted_connection=True;");
//            }
//        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");

            modelBuilder.Entity<TblDepartment>(entity =>
            {
                entity.HasKey(e => e.DepartmentId);

                entity.ToTable("tbl_department");

                entity.Property(e => e.GroupName).IsRequired();

                entity.Property(e => e.Name).IsRequired();
            });

            modelBuilder.Entity<TblProduct>(entity =>
            {
                entity.HasKey(e => e.ProductId);

                entity.ToTable("tbl_product");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.Color).IsRequired();

                entity.Property(e => e.Name).IsRequired();

                entity.Property(e => e.Price).HasColumnType("money");

                entity.Property(e => e.ProductNumber).IsRequired();
            });

            modelBuilder.Entity<TblVendor>(entity =>
            {
                entity.HasKey(e => e.VendorId);

                entity.ToTable("tbl_vendor");

                entity.Property(e => e.Name).IsRequired();
            });
            modelBuilder.Query<SpGetProductByPriceGreaterThan1000>();
            modelBuilder.Query<SpGetProductByID>();
        }
        public async Task<List<SpGetProductByPriceGreaterThan1000>> GetProductByPriceGreaterThan1000Async()
        {
            // Initialization.  
            List<SpGetProductByPriceGreaterThan1000> lst = new List<SpGetProductByPriceGreaterThan1000>();

            try
            {
                // Processing.  
                string sqlQuery = "EXEC [dbo].[GetProductByPriceGreaterThan1000] ";

                lst = await this.Query<SpGetProductByPriceGreaterThan1000>().FromSql(sqlQuery).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            // Info.  
            return lst;
        }



        #region Get product by ID store procedure method.  

        /// <summary>  
        /// Get product by ID store procedure method.  
        /// </summary>  
        /// <param name="productId">Product ID value parameter</param>  
        /// <returns>Returns - List of product by ID</returns>  
        public async Task<List<SpGetProductByID>> GetProductByIDAsync(int productId)
        {
            // Initialization.  
            List<SpGetProductByID> lst = new List<SpGetProductByID>();

            try
            {
                // Settings.  
                SqlParameter usernameParam = new SqlParameter("@product_ID", productId.ToString() ?? (object)DBNull.Value);

                // Processing.  
                string sqlQuery = "EXEC [dbo].[GetProductByID] " +
                                    "@product_ID";

                lst = await this.Query<SpGetProductByID>().FromSql(sqlQuery, usernameParam).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            // Info.  
            return lst;
        }

        #endregion
    }
}
