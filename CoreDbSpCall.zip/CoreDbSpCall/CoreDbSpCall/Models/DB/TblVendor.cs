﻿using System;
using System.Collections.Generic;

namespace CoreDbSpCall.Models.DB
{
    public partial class TblVendor
    {
        public int VendorId { get; set; }
        public string Name { get; set; }
    }
}
