﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CoreDbSpCall.Pages
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using CoreDbSpCall.Models;
    using CoreDbSpCall.Models.DB;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.RazorPages;
    using Microsoft.EntityFrameworkCore;

    /// <summary>  
    /// Index page model class.  
    /// </summary>  
    public class IndexModel : PageModel
    {
        #region Private Properties.  

        /// <summary>  
        /// Database Manager property.  
        /// </summary>  
        private readonly db_core_sp_callContext databaseManager;

        #endregion

        #region Default Constructor method.  

        /// <summary>  
        /// Initializes a new instance of the <see cref="IndexModel"/> class.  
        /// </summary>  
        /// <param name="databaseManagerContext">Database manager context parameter</param>  
        public IndexModel(db_core_sp_callContext databaseManagerContext)
        {
            try
            {
                // Settings.  
                this.databaseManager = databaseManagerContext;
            }
            catch (Exception ex)
            {
                // Info  
                Console.Write(ex);
            }
        }

        #endregion

        #region Public Properties  

        /// <summary>  
        /// Gets or sets department model property.  
        /// </summary>  
        [BindProperty]
        public ProductViewModel ProductVM { get; set; }

        #endregion

        #region On Get method.  

        /// <summary>  
        /// GET: /Index/productId  
        /// </summary>  
        /// <param name="productId">Product ID parameter</param>  
        /// <returns> Returns - index page</returns>  
        public async Task OnGet(int productId = 0)
        {
            // Initialization.  
            this.ProductVM = new ProductViewModel();
            this.ProductVM.ProductID = productId;
            this.ProductVM.ProductDetail = new SpGetProductByID();
            this.ProductVM.ProductsGreaterThan1000 = new List<SpGetProductByPriceGreaterThan1000>();

            try
            {
                // Verification.  
                if (this.ProductVM.ProductID > 0)
                {
                    // Settings.  
                    var details = await this.databaseManager.GetProductByIDAsync(this.ProductVM.ProductID);
                    this.ProductVM.ProductDetail = details.First();
                }

                // Settings.  
                this.ProductVM.ProductsGreaterThan1000 = await this.databaseManager.GetProductByPriceGreaterThan1000Async();
            }
            catch (Exception ex)
            {
                // Info  
                Console.Write(ex);
            }
        }

        #endregion

        #region On Post Detail method.  

        /// <summary>  
        /// POST: /Index/Detail  
        /// </summary>  
        /// <returns>Returns - Appropriate page </returns>  
        public IActionResult OnPostDetail()
        {
            try
            {
                // Verification.  
                if (ModelState.IsValid)
                {
                    // Settings.  
                    string path = "/Index";

                    // Info.  
                    return this.RedirectToPage(path, new { productId = this.ProductVM.ProductID });
                }
            }
            catch (Exception ex)
            {
                // Info  
                Console.Write(ex);
            }

            // Info.  
            return this.Page();
        }

        #endregion
    }
}
